<?php 
if(!defined('BASE_URL')){
	define('BASE_URL', 'http://localhost/project/test/');
}
?>