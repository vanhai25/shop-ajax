<?php 
require_once "app/Controllers/BaseController.php";
require_once "app/Core/DBConnect.php";
require_once "app/Config/config.php";
require_once "libs/functions.php";
require_once "libs/Pager.php";

session_start();

require_once"app/Controllers/Controller.php";
require_once "Views/fontend/footer.php";

?>